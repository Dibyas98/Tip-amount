// let div1 = document.getElementById("div1");
// console.log(div1);

// div1.addEventListener("click", function (eventObject) {
//     console.log(eventObject);
//   console.log("event is triggered!!!!");
// });


// let head = document.getElementById("head2");
// console.log(head);

// let head1 = document.getElementById("heading1");
// // console.log(head1);

// let headings = document.getElementsByTagName("h1");
// console.log(headings);   //array
// headings[0].style.backgroundColor = "cyan";
// headings[1].style.color = "red";

// let div1 = document.getElementById("div1");
// console.log(div1);

// let h1 = document.getElementsByTagName("div");
// console.log(h1);

// div1.style.height = "200px";
// div1.style.width = "200px";
// div1.style.backgroundColor = "purple";


