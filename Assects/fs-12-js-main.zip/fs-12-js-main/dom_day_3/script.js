// "use strict";

// let grandfather = document.getElementById("grandfather");
// let father = document.getElementById("father");
// let son = document.getElementById("son");

// console.log(grandfather,father,son);

// grandfather.addEventListener("click",(e)=>{
//     console.log(e);
//     e.stopPropagation();
//     alert("grandfather")
// })

// father.addEventListener("click",(e)=>{
//     e.stopPropagation();
//     alert("father")
// })

// son.addEventListener("click",(e)=>{
//     e.stopPropagation();
//     alert("son")
// })

// let myList = document.getElementById("list");
// // console.log(myList);

// myList.addEventListener("click", (event)=>{
//     // console.log(event);
//     if(event.target.nodeName == 'LI'){
//         console.log(event.target.outerText);
//     }
// })





// let a = 10;
// console.log(a);

// function sum(){

// }
// sum();










// console.log("hello world!!!");

// let btn = document.getElementsByTagName("button");
// let btn = document.getElementById("btn");
// console.log(btn);

// function btnClicked(){
//     alert("This button is clicked!!")
// }

// btn.addEventListener("click", function(e){
//     console.log("btn is clicked!!!", e);
// })


// let inputTag = document.getElementById("input1");
// inputTag.addEventListener("keyup", function(e){
//     console.log("Key is pressed!!!",e.keyCode);
// })






let h1 = document.querySelectorAll("h1");

let head1 = document.getElementsByClassName("lio");
console.log(head1);
console.log(h1);

























